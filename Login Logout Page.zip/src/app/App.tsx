import { useState } from "react";
import { LoginPage } from "./components/LoginPage";
import { SignUpPage } from "./components/SignUpPage";
import { Dashboard } from "./components/Dashboard";
import { AdminUserManagement } from "./components/AdminUserManagement";
import { BookGravePlot } from "./components/BookGravePlot";
import { GraveyardMap } from "./components/GraveyardMap";
import { GenerateReport } from "./components/GenerateReport";
import { Notifications } from "./components/Notifications";
import { FamilyPortal } from "./components/FamilyPortal";
import { toast } from "sonner";
import { Toaster } from "./components/ui/sonner";

type Page = "dashboard" | "manage-users" | "book-plot" | "map" | "reports" | "notifications" | "family-portal";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [showSignUp, setShowSignUp] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");

  const handleLogin = (email: string, password: string) => {
    // For demo purposes, accept any credentials
    // In a real app, this would validate against a backend
    setUserEmail(email);
    setIsAuthenticated(true);
    setCurrentPage("dashboard");
    toast.success("Successfully logged in!");
  };

  const handleSignUp = (
    name: string,
    email: string,
    password: string,
    phone: string,
  ) => {
    // For demo purposes, accept any credentials
    // In a real app, this would create a new user in the backend
    setUserEmail(email);
    setIsAuthenticated(true);
    setCurrentPage("dashboard");
    toast.success(
      `Account created successfully! Welcome ${name}`,
    );
  };

  const handleLogout = () => {
    setUserEmail("");
    setIsAuthenticated(false);
    setShowSignUp(false);
    setCurrentPage("dashboard");
    toast.info("Logged out successfully");
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const handleBackToDashboard = () => {
    setCurrentPage("dashboard");
  };

  const renderPage = () => {
    switch (currentPage) {
      case "manage-users":
        return <AdminUserManagement onBack={handleBackToDashboard} />;
      case "book-plot":
        return <BookGravePlot onBack={handleBackToDashboard} />;
      case "map":
        return <GraveyardMap onBack={handleBackToDashboard} />;
      case "reports":
        return <GenerateReport onBack={handleBackToDashboard} />;
      case "notifications":
        return <Notifications onBack={handleBackToDashboard} />;
      case "family-portal":
        return <FamilyPortal onBack={handleBackToDashboard} />;
      default:
        return (
          <Dashboard
            userEmail={userEmail}
            onLogout={handleLogout}
            onNavigate={handleNavigate}
          />
        );
    }
  };

  return (
    <div className="size-full">
      <Toaster />
      {isAuthenticated ? (
        renderPage()
      ) : showSignUp ? (
        <SignUpPage
          onSignUp={handleSignUp}
          onSwitchToLogin={() => setShowSignUp(false)}
        />
      ) : (
        <LoginPage
          onLogin={handleLogin}
          onSwitchToSignUp={() => setShowSignUp(true)}
        />
      )}
    </div>
  );
}