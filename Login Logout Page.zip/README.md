
  # Login Logout Page

  This is a code bundle for Login Logout Page. The original project is available at https://www.figma.com/design/hl0ul11mUhGIGTcM5WBG7e/Login-Logout-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  